# अदालत पेशी रिमाइन्डर — Android project

A simple offline-first Android app source project for recording court hearing dates in Bikram Sambat (वि.सं.) and receiving reminders 1 day and 2 hours before the selected court attendance time.

## Included
- Nepali interface
- वादी / प्रतिवादी selector
- Case name
- BS hearing date entry (`YYYY-MM-DD`, Devanagari or Latin digits)
- Court attendance time picker
- 1-day and 2-hour reminders
- Local storage using Android SharedPreferences
- Edit/delete cases
- Re-schedule reminders after device restart
- BS-to-AD conversion using the Nepali Date Picker core library

## Build an APK
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the extracted `CourtCaseReminderAndroid` folder.
4. Allow Gradle sync and dependency downloads.
5. Connect an Android phone with USB debugging enabled, or use an emulator.
6. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
7. Install the generated APK on your phone.

## Android permissions
- Allow notifications when Android asks.
- On Android 12+, exact-alarm access may need to be enabled in Android Settings for the most punctual reminders. If not granted, Android uses an inexact alarm fallback.
- Battery optimization or aggressive phone-maker background restrictions can delay notifications. Allow the app to run in the background.

## Important
- Case information is stored locally on the device. There is no cloud backup or account sync in this starter version.
- The date converter dependency is downloaded from Maven Central during Gradle sync. Date conversion is supported within the library's published BS/AD conversion range.
- The project source is provided; a signed, installable APK has not been built in this environment because Android SDK/Gradle build tools are not available here.
