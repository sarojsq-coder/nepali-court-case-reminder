package np.saroj.courtereminder;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

import dev.shivathapaa.nepalidatepickerkmp.NepaliDateConverter;
import dev.shivathapaa.nepalidatepickerkmp.CustomCalendar;

public class MainActivity extends Activity {
    static final String PREFS = "court_cases";
    static final String KEY = "items";
    LinearLayout root, list;
    ScrollView pageScroll;
    EditText caseName, bsDate, courtTime;
    Spinner partyType;
    CheckBox alertDay, alertTwoHours;
    Button saveButton;
    String editingId = null;

    int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFF123D5A);
        getWindow().setNavigationBarColor(0xFF123D5A);
        createNotificationChannel();
        requestNotificationPermission();
        buildScreen();
        renderCases();
    }

    TextView text(String value, int size, boolean bold, int color) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    void addGap(LinearLayout parent, int h) {
        View v = new View(this);
        parent.addView(v, new LinearLayout.LayoutParams(1, dp(h)));
    }

    EditText edit(String hint, String value, int inputType) {
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setText(value);
        e.setHint(hint);
        e.setTextSize(16);
        e.setInputType(inputType);
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF8AA2B2));
        return e;
    }

    void buildScreen() {
        pageScroll = new ScrollView(this);
        root = column();
        root.setPadding(dp(18), dp(18), dp(18), dp(24));
        root.setBackgroundColor(0xFFF4F7FA);
        pageScroll.addView(root);
        setContentView(pageScroll);

        LinearLayout header = column();
        header.setPadding(dp(18), dp(18), dp(18), dp(18));
        header.setBackgroundColor(0xFF174B70);
        TextView title = text("⚖  अदालत पेशी रिमाइन्डर", 23, true, 0xFFFFFFFF);
        header.addView(title);
        TextView subtitle = text("तपाईंको मुद्दा र पेशी मिति सम्झाउने साथी", 13, false, 0xFFDCEAF3);
        header.addView(subtitle);
        root.addView(header);
        addGap(root, 16);

        TextView section = text("नयाँ मुद्दा थप्नुहोस्", 19, true, 0xFF173D56);
        root.addView(section);
        addGap(root, 8);

        root.addView(text("मुद्दामा तपाईंको पक्ष", 14, true, 0xFF344B5B));
        partyType = new Spinner(this);
        String[] types = {"वादी", "प्रतिवादी"};
        partyType.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, types));
        root.addView(partyType, new LinearLayout.LayoutParams(-1, dp(48)));

        addGap(root, 5);
        root.addView(text("मुद्दाको नाम", 14, true, 0xFF344B5B));
        caseName = edit("उदाहरण: जग्गा खिचोला मुद्दा", "",  android.text.InputType.TYPE_CLASS_TEXT);
        root.addView(caseName, new LinearLayout.LayoutParams(-1, dp(54)));

        addGap(root, 5);
        root.addView(text("पेशी हुने मिति (वि.सं.)", 14, true, 0xFF344B5B));
        bsDate = edit("२०८३-०८-२५", "", android.text.InputType.TYPE_CLASS_TEXT);
        root.addView(bsDate, new LinearLayout.LayoutParams(-1, dp(54)));
        TextView dateHint = text("मिति YYYY-MM-DD ढाँचामा लेख्नुहोस्। नेपाली वा अंग्रेजी अंक दुवै चल्छन्।", 11, false, 0xFF687D8A);
        root.addView(dateHint);

        addGap(root, 5);
        root.addView(text("अदालत जानुपर्ने समय", 14, true, 0xFF344B5B));
        courtTime = edit("उदाहरण: १०:०० (२४ घण्टे)", "10:00", android.text.InputType.TYPE_CLASS_DATETIME);
        courtTime.setFocusable(false);
        courtTime.setOnClickListener(v -> showTimePicker());
        root.addView(courtTime, new LinearLayout.LayoutParams(-1, dp(54)));

        addGap(root, 8);
        root.addView(text("सूचना आउने समय", 14, true, 0xFF344B5B));
        alertDay = new CheckBox(this); alertDay.setText("१ दिन अगाडि"); alertDay.setTextSize(15); alertDay.setChecked(true);
        alertTwoHours = new CheckBox(this); alertTwoHours.setText("२ घण्टा अगाडि"); alertTwoHours.setTextSize(15); alertTwoHours.setChecked(true);
        root.addView(alertDay); root.addView(alertTwoHours);

        addGap(root, 10);
        saveButton = new Button(this);
        saveButton.setText("मुद्दा सुरक्षित गर्नुहोस्");
        saveButton.setAllCaps(false);
        saveButton.setTextColor(0xFFFFFFFF);
        saveButton.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF17618B));
        saveButton.setOnClickListener(v -> saveCase());
        root.addView(saveButton, new LinearLayout.LayoutParams(-1, dp(52)));

        addGap(root, 22);
        root.addView(text("आगामी तथा सुरक्षित मुद्दाहरू", 19, true, 0xFF173D56));
        addGap(root, 8);
        list = column();
        root.addView(list);
    }

    void showTimePicker() {
        int h = 10, m = 0;
        try { String[] p = courtTime.getText().toString().split(":"); h = Integer.parseInt(p[0]); m = Integer.parseInt(p[1]); } catch(Exception ignored) {}
        new TimePickerDialog(this, (v, hour, minute) -> courtTime.setText(String.format(Locale.US, "%02d:%02d", hour, minute)), h, m, true).show();
    }

    String latinDigits(String s) {
        StringBuilder b = new StringBuilder();
        for (char c : s.toCharArray()) {
            if (c >= '०' && c <= '९') b.append((char)('0' + c - '०'));
            else b.append(c);
        }
        return b.toString().trim();
    }

    JSONObject readCases() {
        try { return new JSONObject().put("items", new JSONArray(getSharedPreferences(PREFS, 0).getString(KEY, "[]"))); }
        catch(Exception e) { return new JSONObject().put("items", new JSONArray()); }
    }

    JSONArray cases() { return readCases().optJSONArray("items"); }

    void saveCase() {
        String name = caseName.getText().toString().trim();
        String date = latinDigits(bsDate.getText().toString()).replace('/', '-');
        String time = courtTime.getText().toString().trim();
        if (name.isEmpty()) { toast("कृपया मुद्दाको नाम लेख्नुहोस्।"); return; }
        if (!date.matches("\\d{4}-\\d{1,2}-\\d{1,2}")) { toast("कृपया पेशी मिति YYYY-MM-DD ढाँचामा लेख्नुहोस्।"); return; }
        if (!alertDay.isChecked() && !alertTwoHours.isChecked()) { toast("कम्तीमा एउटा सूचना समय छान्नुहोस्।"); return; }
        try {
            String[] d = date.split("-");
            int y = Integer.parseInt(d[0]), mo = Integer.parseInt(d[1]), day = Integer.parseInt(d[2]);
            CustomCalendar ad = NepaliDateConverter.INSTANCE.convertNepaliToEnglish(y, mo, day);
            String[] tm = time.split(":");
            int hour = Integer.parseInt(tm[0]), minute = Integer.parseInt(tm[1]);
            LocalDateTime hearing = LocalDateTime.of(ad.getYear(), ad.getMonth(), ad.getDayOfMonth(), hour, minute);
            String id = editingId == null ? String.valueOf(System.currentTimeMillis()) : editingId;
            JSONArray old = cases(), updated = new JSONArray();
            JSONObject item = new JSONObject();
            item.put("id", id); item.put("party", partyType.getSelectedItem().toString());
            item.put("name", name); item.put("bs", String.format(Locale.US, "%04d-%02d-%02d", y, mo, day));
            item.put("time", time); item.put("adMillis", hearing.atZone(ZoneId.of("Asia/Kathmandu")).toInstant().toEpochMilli());
            item.put("oneDay", alertDay.isChecked()); item.put("twoHours", alertTwoHours.isChecked());
            for (int i=0; i<old.length(); i++) if (!old.getJSONObject(i).optString("id").equals(id)) updated.put(old.getJSONObject(i));
            updated.put(item);
            getSharedPreferences(PREFS, 0).edit().putString(KEY, updated.toString()).apply();
            scheduleForCase(this, item);
            clearForm(); renderCases();
            toast("मुद्दा सुरक्षित भयो र सूचना सेट गरियो।");
        } catch(Exception e) {
            toast("मिति वा समय मिलेन। सही वि.सं. मिति र समय जाँच गर्नुहोस्।");
        }
    }

    void clearForm() {
        editingId = null; caseName.setText(""); bsDate.setText(""); courtTime.setText("10:00");
        partyType.setSelection(0); alertDay.setChecked(true); alertTwoHours.setChecked(true);
        saveButton.setText("मुद्दा सुरक्षित गर्नुहोस्");
    }

    void renderCases() {
        if (list == null) return;
        list.removeAllViews();
        JSONArray a = cases();
        if (a.length() == 0) {
            TextView empty = text("अहिलेसम्म कुनै मुद्दा थपिएको छैन।", 14, false, 0xFF687D8A);
            empty.setPadding(dp(8), dp(12), dp(8), dp(12)); list.addView(empty); return;
        }
        for (int i=0; i<a.length(); i++) {
            JSONObject o = a.optJSONObject(i); if (o == null) continue;
            LinearLayout card = column();
            card.setPadding(dp(14), dp(12), dp(14), dp(10));
            card.setBackgroundColor(0xFFFFFFFF);
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2); cp.bottomMargin = dp(10);
            list.addView(card, cp);
            TextView nm = text(o.optString("name"), 17, true, 0xFF173D56); card.addView(nm);
            card.addView(text(o.optString("party") + " पक्ष  •  पेशी: " + o.optString("bs"), 14, false, 0xFF3F5968));
            card.addView(text("अदालत जानुपर्ने समय: " + o.optString("time"), 14, false, 0xFF3F5968));
            LinearLayout actions = new LinearLayout(this); actions.setGravity(Gravity.END);
            Button edit = new Button(this); edit.setText("सम्पादन"); edit.setAllCaps(false);
            edit.setOnClickListener(v -> loadForEdit(o));
            Button del = new Button(this); del.setText("हटाउनुहोस्"); del.setAllCaps(false);
            del.setTextColor(0xFFB3261E); del.setOnClickListener(v -> confirmDelete(o));
            actions.addView(edit); actions.addView(del); card.addView(actions);
        }
    }

    void loadForEdit(JSONObject o) {
        editingId = o.optString("id");
        caseName.setText(o.optString("name")); bsDate.setText(o.optString("bs"));
        courtTime.setText(o.optString("time"));
        partyType.setSelection(o.optString("party").equals("प्रतिवादी") ? 1 : 0);
        alertDay.setChecked(o.optBoolean("oneDay", true)); alertTwoHours.setChecked(o.optBoolean("twoHours", true));
        saveButton.setText("परिवर्तन सुरक्षित गर्नुहोस्");
        pageScroll.smoothScrollTo(0, 0);
    }

    void confirmDelete(JSONObject o) {
        new AlertDialog.Builder(this).setTitle("मुद्दा हटाउने?")
            .setMessage("यो मुद्दा र यसका रिमाइन्डर हटाउने हो?")
            .setNegativeButton("रद्द", null)
            .setPositiveButton("हटाउनुहोस्", (d,w) -> {
                String id = o.optString("id");
                cancelAlarms(this, id);
                JSONArray old = cases(), fresh = new JSONArray();
                for (int i=0;i<old.length();i++) if (!old.optJSONObject(i).optString("id").equals(id)) fresh.put(old.optJSONObject(i));
                getSharedPreferences(PREFS,0).edit().putString(KEY,fresh.toString()).apply();
                renderCases(); toast("मुद्दा हटाइयो।");
            }).show();
    }

    static void scheduleForCase(Context c, JSONObject o) {
        long hearing = o.optLong("adMillis");
        String id = o.optString("id");
        cancelAlarms(c, id);
        if (o.optBoolean("oneDay")) schedule(c, id, 1, hearing - 24L*60*60*1000, o.optString("name"), o.optString("bs"), o.optString("time"));
        if (o.optBoolean("twoHours")) schedule(c, id, 2, hearing - 2L*60*60*1000, o.optString("name"), o.optString("bs"), o.optString("time"));
    }

    static void schedule(Context c, String id, int type, long when, String name, String date, String time) {
        if (when <= System.currentTimeMillis()) return;
        int request = Math.abs((id + type).hashCode());
        Intent intent = new Intent(c, ReminderReceiver.class);
        intent.putExtra("name", name); intent.putExtra("date", date); intent.putExtra("time", time);
        intent.putExtra("type", type); intent.putExtra("id", id);
        PendingIntent pi = PendingIntent.getBroadcast(c, request, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        } catch (SecurityException ex) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        }
    }

    static void cancelAlarms(Context c, String id) {
        AlarmManager am = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        for (int type=1; type<=2; type++) {
            int request = Math.abs((id + type).hashCode());
            Intent i = new Intent(c, ReminderReceiver.class);
            PendingIntent pi = PendingIntent.getBroadcast(c, request, i, PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
            if (pi != null) { am.cancel(pi); pi.cancel(); }
        }
    }

    public static void rescheduleAll(Context c) {
        try {
            JSONArray a = new JSONArray(c.getSharedPreferences(PREFS,0).getString(KEY,"[]"));
            for (int i=0;i<a.length();i++) scheduleForCase(c, a.getJSONObject(i));
        } catch(Exception ignored) {}
    }

    void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel("court_hearing", "अदालत पेशी सूचना", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("पेशीभन्दा अगाडि आउने सम्झना");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }

    void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 10);
    }

    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
}
