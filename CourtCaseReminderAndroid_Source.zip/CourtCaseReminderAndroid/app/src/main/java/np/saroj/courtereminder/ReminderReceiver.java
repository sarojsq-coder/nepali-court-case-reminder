package np.saroj.courtereminder;

import android.app.*;
import android.content.*;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String name = intent.getStringExtra("name");
        String date = intent.getStringExtra("date");
        String time = intent.getStringExtra("time");
        int type = intent.getIntExtra("type", 1);
        String lead = type == 1 ? "भोलि पेशी छ" : "२ घण्टापछि पेशी छ";
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
            ? new Notification.Builder(context, "court_hearing")
            : new Notification.Builder(context);
        b.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("अदालत पेशी सम्झना")
            .setContentText(lead + ": " + name + " (" + date + ", " + time + ")")
            .setStyle(new Notification.BigTextStyle().bigText(lead + "। मुद्दा: " + name + "। पेशी मिति: " + date + "। अदालत जानुपर्ने समय: " + time))
            .setAutoCancel(true);
        NotificationManager nm = (NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify((intent.getStringExtra("id") + type).hashCode(), b.build());
    }
}
